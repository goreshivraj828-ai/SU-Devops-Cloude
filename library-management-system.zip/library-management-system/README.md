# Library Management System

A beginner-friendly Java console project. Add books, view and search the catalog, borrow or return books, and delete entries. Data is saved automatically in `books.txt` between runs.

## Requirements

JDK 8 or newer. Verify with `java -version` and `javac -version`.

## Run

Open a terminal in this folder:

```bash
javac LibraryManagementSystem.java
java LibraryManagementSystem
```

Use the numbered menu. For example, choose `1`, enter a title and author, then choose `2` to view the book.

## Upload to GitHub

Create an empty GitHub repository named `library-management-system` (leave its README option unchecked). In the extracted project folder, run:

```bash
git init
git add .
git commit -m "Add Java library management system"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/library-management-system.git
git push -u origin main
```

Replace `YOUR_USERNAME` with your GitHub username. If Git requests your identity, set `git config --global user.name "Your Name"` and `git config --global user.email "you@example.com"`, then retry the commit and push. GitHub may open a browser to authenticate.
