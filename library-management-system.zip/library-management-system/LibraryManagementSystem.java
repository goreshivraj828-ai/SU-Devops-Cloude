import java.io.*;
import java.util.*;

public class LibraryManagementSystem {
    static final Scanner scanner = new Scanner(System.in);
    static final ArrayList<Book> books = new ArrayList<>();
    static final File data = new File("books.txt");
    static int nextId = 1;

    static class Book implements Serializable {
        private static final long serialVersionUID = 1L;
        int id;
        String title, author;
        boolean borrowed;
        Book(int id, String title, String author) {
            this.id = id; this.title = title; this.author = author;
        }
        public String toString() {
            return id + " | " + title + " | " + author + " | " + (borrowed ? "Borrowed" : "Available");
        }
    }

    public static void main(String[] args) {
        load();
        while (true) {
            System.out.println("\n=== LIBRARY MANAGEMENT SYSTEM ===");
            System.out.println("1. Add book\n2. View books\n3. Search books\n4. Borrow book\n5. Return book\n6. Delete book\n0. Exit");
            int choice = number("Choose: ");
            switch (choice) {
                case 1: add(); break;
                case 2: list(); break;
                case 3: search(); break;
                case 4: setBorrowed(true); break;
                case 5: setBorrowed(false); break;
                case 6: delete(); break;
                case 0: System.out.println("Goodbye!"); return;
                default: System.out.println("Invalid option.");
            }
        }
    }

    static int number(String prompt) {
        while (true) {
            System.out.print(prompt);
            try { return Integer.parseInt(scanner.nextLine().trim()); }
            catch (NumberFormatException e) { System.out.println("Enter a whole number."); }
        }
    }
    static String text(String prompt) {
        while (true) {
            System.out.print(prompt);
            String s = scanner.nextLine().trim();
            if (!s.isEmpty()) return s;
            System.out.println("Cannot be empty.");
        }
    }
    static Book find(int id) {
        for (Book b : books) if (b.id == id) return b;
        return null;
    }
    static void add() {
        Book b = new Book(nextId++, text("Title: "), text("Author: "));
        books.add(b); save();
        System.out.println("Added book ID " + b.id);
    }
    static void list() {
        if (books.isEmpty()) System.out.println("No books found.");
        else for (Book b : books) System.out.println(b);
    }
    static void search() {
        String q = text("Search title or author: ").toLowerCase(Locale.ROOT);
        int matches = 0;
        for (Book b : books) {
            if (b.title.toLowerCase(Locale.ROOT).contains(q) || b.author.toLowerCase(Locale.ROOT).contains(q)) {
                System.out.println(b); matches++;
            }
        }
        if (matches == 0) System.out.println("No matches.");
    }
    static void setBorrowed(boolean state) {
        Book b = find(number("Book ID: "));
        if (b == null) System.out.println("Book not found.");
        else if (b.borrowed == state) System.out.println(state ? "Already borrowed." : "Already available.");
        else { b.borrowed = state; save(); System.out.println(state ? "Borrowed." : "Returned."); }
    }
    static void delete() {
        Book b = find(number("Book ID: "));
        if (b == null) System.out.println("Book not found.");
        else { books.remove(b); save(); System.out.println("Deleted."); }
    }
    static void save() {
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(data))) {
            out.writeObject(books);
            out.writeInt(nextId);
        } catch (IOException e) { System.out.println("Save failed: " + e.getMessage()); }
    }
    @SuppressWarnings("unchecked")
    static void load() {
        if (!data.exists()) return;
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(data))) {
            books.addAll((ArrayList<Book>) in.readObject());
            nextId = in.readInt();
        } catch (IOException | ClassNotFoundException | ClassCastException e) {
            books.clear(); nextId = 1;
            System.out.println("Could not load books.txt: " + e.getMessage());
        }
    }
}
